
public class HelloWorldNao {
	public static void main (String args[])
	{
		System.out.println ("Qualquer coisa menos Hello World!");
	}
}
/* Vai demorar um pouco até eu entender esses publics e statics e privates,
mas parace ser uma linguagem bem legal de usar, mais tranquila que o C */