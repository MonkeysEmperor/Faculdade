package Ex4;

interface Programador {
	boolean codedPerfectly ();
	double getSalary();

}
