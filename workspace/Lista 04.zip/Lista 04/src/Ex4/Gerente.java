package Ex4;
interface Gerente {
	int getWorkHours();
	boolean goodLeadership();
}
