package Ex3;

interface Figura2D
{
	double calculaÁrea();
	double calculaPerímetro();
	void mudaCor(String cor);
	String pegaCor();
}
