
public class Cliente3 {
	
}
