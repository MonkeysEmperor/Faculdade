package Ex10;

public class Pessoa {
	double altura;
}
