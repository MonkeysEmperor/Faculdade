package Ex10;

public class Robô extends Pessoa/*, Máquina -> o compilador não deixa ter mais classes*/{
	
}
