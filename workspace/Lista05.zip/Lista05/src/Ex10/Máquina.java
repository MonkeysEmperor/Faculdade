package Ex10;

public class Máquina {
	String Material;
}
