package Ex8;

public class Pessoa {
	public void forcePush()
	{
		System.out.println("Vou tentar fazer um Force Push!");
		consegui();
	}
	public void consegui()
	{
		System.out.println("Não consegui :(");
	}
}
