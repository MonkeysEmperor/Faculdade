package Ex6;

public class Animal {
	void nasce() {
		System.out.println("Nasceu um animal");
		}
		void cresce() {
		System.out.println("Cresceu um animal");
		}
}
